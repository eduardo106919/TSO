#include "metaindex.h"
#include <stdio.h>

//For exercise 1.3 see man pages for
//int pthread_mutex_lock(pthread_mutex_t *mutex)
//int pthread_mutex_unlock(pthread_mutex_t *mutex);
//int pthread_cond_wait(pthread_cond_t *cond, pthread_mutex_t *mutex);
//int pthread_cond_signal(pthread_cond_t *cond);
//int pthread_cond_broadcast(pthread_cond_t *cond);

Index* index_init(){

	//allocate memory for the index
	Index *index = malloc(sizeof(Index));

	//GHashTable initialization
	index->htable = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, g_free);

	//Useful for exercise 1.3
	//mutex variable initialization
	//int pthread_mutex_init(pthread_mutex_t *mutex,const pthread_mutexattr_t *attr);
	//attr can be used to define non-default attributes (e.g., recursive lock)
	pthread_mutex_init(&index->mutex, NULL);

	//Useful for exercise 1.3
	//condition variable initialization
	//int pthread_cond_init(pthread_cond_t *cond, const pthread_condattr_t *attr);
	//attr can be used to define non-default attributes (e.g., recursive lock)
	pthread_cond_init(&index->cond, NULL);
	return index;

}

//Note: remember that memory allocation and copying must be done here
int index_add(Index *index, char* filename, Filemeta meta){

	return 0;
}

int index_get(Index *index, char* filename, Filemeta *meta){

	return 0;

}

int index_increfs(Index *index, char* filename){

	return 0;
}


//Exercise 1.3
int index_wait_refs(Index* index, char* filename, int nrefs){

	return 0;
}


int index_remove(Index* index, char* filename){

	return 0;
}

void index_destroy(Index* index){

	//destroy hashtable
	g_hash_table_destroy(index->htable);

	//Useful for exercice 1.3
	//destroy mutex and cond variables
	pthread_mutex_destroy(&index->mutex);
    pthread_cond_destroy(&index->cond);

	free(index);
}